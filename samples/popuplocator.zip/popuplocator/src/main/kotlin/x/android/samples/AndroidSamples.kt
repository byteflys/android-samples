package x.android.samples

object AndroidSamples {

}